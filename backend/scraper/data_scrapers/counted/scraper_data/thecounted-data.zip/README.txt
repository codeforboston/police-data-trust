Please credit the Guardian as the source of this data in any work you do with it. Please link to http://www.theguardian.com/thecounted.

We'd love to know about how you're using the data and what you've made with it. Let us know by emailing thecounted@theguardian.com. Thank you.
